package Realestate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Chng_details {
	WebDriver dr;
	By link = By.xpath("//*[@id='wp-admin-bar-my-account']/a");
	//*[@id="wp-admin-bar-my-account"]/a/span
	By editname = By.xpath("//*[@id='wp-admin-bar-my-account']/a/span");
	By lastname = By.xpath("//*[@id='last_name']");
	By phno = By.xpath("//*[@id='phone']");
	By submit = By.xpath("//*[@id='submit']");
	
	public Chng_details(WebDriver dr)
	{
		this.dr = dr;
	}
	
	
	public void link()
	{
		dr.findElement(link).click();
	}
	public void edit_name()
	{
		dr.findElement(editname).click();
	}
	public void last_name(String ln)
	{
		dr.findElement(lastname).clear();
		dr.findElement(lastname).sendKeys(ln);
	}
	public void phone_no(String pn)
	{
		dr.findElement(phno).clear();
		dr.findElement(phno).sendKeys(pn);
	}
	public void submit_btn()
	{
		dr.findElement(submit).click();
	}
	
	public void do_change(String u, String p, String pno)
	{
		this.link();
		this.edit_name();
		this.last_name(p);
		this.phone_no(pno);
		this.submit_btn();
	}
	
	
	
	
}
