package Realestate;

//import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Pswd_change {
	
	WebDriver dr;
	
	By link = By.xpath("//*[@id='wp-admin-bar-my-account']/a");
	//*[@id="wp-admin-bar-my-account"]/a/span
	By editname = By.xpath("//*[@id='wp-admin-bar-my-account']/a/span");
	By gnrtpwd = By.xpath("//*[@id='password']/td/button");
	By pwdtxt = By.xpath("//*[@id='pass1-text']");
	By chkbox = By.name("pw_weak");
	By submit = By.xpath("//*[@id='submit']");
	
	public Pswd_change(WebDriver dr)
	{
		this.dr = dr;
	}
	public void link()
	{
		dr.findElement(link).click();
	}
	public void edit_name()
	{
		dr.findElement(editname).click();
	}
	public void generate(String newpd)
	{
		dr.findElement(gnrtpwd).click();
		WebDriverWait wt =new WebDriverWait(dr, 10);
		wt.until(ExpectedConditions.elementToBeClickable(pwdtxt));
		dr.findElement(pwdtxt).clear();
		dr.findElement(pwdtxt).sendKeys(newpd);
	}
	public void checkbox()
	{
		java.util.List<WebElement> rb = dr.findElements(chkbox);
		((WebElement) rb.get(0)).click();
	}
	public void submit_btn()
	{
		dr.findElement(submit).click();
	}
	public void do_changepwd(String npwd)
	{
		this.link();
		this.edit_name();
		this.generate(npwd);
		this.submit_btn();
	}
	public String get_text()
	{
		return dr.findElement(By.xpath("//*[@id='message']/p/strong")).getText();
	}
	
}
