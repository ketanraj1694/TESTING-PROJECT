package Realestate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage 
{
WebDriver dr;
By profile_xp = By.xpath("//*[@id='wp-admin-bar-user-info']/a/span");



public HomePage(WebDriver dr)
{
	this.dr = dr;
}



public String get_title() {
	
	return dr.getTitle();
}
}