package Realestate;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LostPswd {

	WebDriver dr;
	By link = By.className("sign-in");
	By lostpwd = By.linkText("Lost Your Password?"); 
	//By.xpath("//*[@id='tab1']/form/p[4]/a");
	By emailid = By.xpath("//*[@id=\"user_login\"]");
	By btn = By.xpath("//*[@id='lostpasswordform']/p[2]/input");
	//*[@id="tab1"]/form/p[4]/a
	
	public LostPswd(WebDriver dr)
	{
		this.dr = dr;
	}
	
	
	public void link()
	{
		dr.findElement(link).click();
	}
	public void link1() throws AWTException
	{	
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_DOWN);
		robot.keyPress(KeyEvent.VK_DOWN);
		dr.findElement(lostpwd).click();
	}
	
	public void email(String eid)
	{
		dr.findElement(emailid).sendKeys(eid);
	}
	/*public void button()
	{
		dr.findElement(btn).click();
	}*/
	public void Reset(String e) throws AWTException
	{
		this.link();
		this.link1();
		this.email(e);
				
	}
	public String get_msg()
	{
		return dr.getTitle();
	}
}
