package Realestate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;

public class Login {
			WebDriver dr;
			
			By link = By.className("sign-in");
			
			By uname = By.xpath("//*[@id='user_login']");
			By pwd = By.xpath("//*[@id='user_pass']");
			By btn = By.xpath("//*[@id='tab1']/form/p[3]/input");
			
			public void link()
			{
				dr.findElement(link).click();
			}
			public Login(WebDriver dr)
			{
				this.dr = dr;
			}
			public void set_uname(String un)
			{
				dr.findElement(uname).sendKeys(un);
			}
			public void set_pwd(String ps)
			{
				dr.findElement(pwd).sendKeys(ps);
			}
			public void click_btn()
			{
				dr.findElement(btn).click();
			}
			
			public void do_login(String u, String p)
			{
				this.link();
				this.set_uname(u);
				this.set_pwd(p);
				this.click_btn();
				
			}
			public String get_title()
			{
				return dr.getTitle();
			}

	 
	 
}
