package Realestate;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LogOut {
	WebDriver dr;
	By link = By.xpath("//*[@id='wp-admin-bar-my-account']/a");
	By editname = By.xpath("//*[@id='wp-admin-bar-my-account']/a/span");
	//*[@id="wp-admin-bar-logout"]/a
	By lgout = By.xpath("//*[@id='wp-admin-bar-my-account']//div/ul//a[text()='Log Out']");
		
	public LogOut(WebDriver dr)
	{
		this.dr = dr;
	}
		
	public void link()
	{
		dr.findElement(link).click();
	}
	
	public void edit_name()
	{
		dr.findElement(editname).click();
	}
	public void log_out()
	
	{	
			Actions action = new Actions(dr);
			WebElement element = dr.findElement(link);
			action.moveToElement(element).perform();
		WebDriverWait wt =new WebDriverWait(dr, 50);
		wt.until(ExpectedConditions.elementToBeClickable(lgout));
			dr.findElement(lgout).click();
	}
	
	public void do_logout(String npwd)
	{
		this.link();
		this.edit_name();
		this.log_out();
	}
	
	public String get_result()
	{
		return dr.findElement(By.xpath("//*[@id='titlebar']/div/div/div/h2")).getText();
	}
	
}
