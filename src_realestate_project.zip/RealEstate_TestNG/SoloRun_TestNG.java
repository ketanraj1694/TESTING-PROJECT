package RealEstate_TestNG;

import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import Realestate.Login;
import Realestate.LostPswd;
import Realestate.Pswd_change;
import Realestate.Chng_details;
import Realestate.HomePage;
import Realestate.LogOut;

public class SoloRun_TestNG {
	  

WebDriver dr;
Login lg;
HomePage hp;
LostPswd lp;
Chng_details chng;
Pswd_change pswd;
LogOut lgout;

@BeforeClass
public void launchBrowser() {
			
			System.setProperty("webdriver.chrome.driver","E:\\chromedriver.exe");
			dr = new ChromeDriver();
			dr.manage().window().maximize();
			dr.get("http://realestate.upskills.in/");
}
  
	
	  //TEST CASE NOT WORKING
@Test	
public void forgot_pwd() throws InterruptedException, AWTException {
			  lp = new LostPswd(dr);
			  //Thread.sleep(5000);
			  	
			  lp.link();
			  Thread.sleep(3000);
			  lp.link1();
			  
			  lp.Reset("manaswinilokare618@gmail.com");
			  /*//String a_msg = lp.get_msg();
		String a = "A confirmation link has been sent to your email address. Message should get displayed & "
				+ "confirmation mail should be sent to registered mail id";
		String b = "The email could not be sent. Possible reason: your host may have disabled the mail() function.";
		//Assert.assertEquals(a, b);
	    */}
	
 //@Test(priority = 1)
	public void test_login_page()
	{
	
		lg = new Login(dr);
		hp = new HomePage(dr);
	
		lg.do_login("admin", "admin@123");
		dr.getTitle();
		
		String actual_pn =hp.get_title();
		Assert.assertTrue(actual_pn.contains("Real Estate � WordPress"));
	}
 
//@Test(priority = 2)
	public void change_details()
	{
	
		chng = new Chng_details(dr);
		chng.edit_name();
		chng.last_name("manzoor");
		chng.phone_no("9876543210");
		chng.submit_btn();
}
 
 //@Test(priority = 3)
	public void change_pwd()
	{
	
		pswd = new Pswd_change(dr);
		pswd.edit_name();
		pswd.generate("admin@123");
		pswd.checkbox();
		pswd.submit_btn();
		dr.getTitle();
		
		String actual_pn =pswd.get_text();
		Assert.assertEquals(actual_pn, "Profile updated.");
}
 
 //@Test(priority = 4)
	public void logout_func()
	{
	
		lgout = new LogOut(dr);
		lgout.log_out();
		
		
		String acn = lgout.get_result();
		Assert.assertEquals(acn,"My Profile" );
} 
} 

