package RealEstate_TestNG;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Realestate.Chng_details;
import Realestate.HomePage;
import Realestate.LogOut;
import Realestate.Login;
import Realestate.LostPswd;
import Realestate.Pswd_change;

public class Set2_TestNG {
	
	  
	WebDriver drs;
	Login lgs;
	HomePage hps;
	LostPswd lps;
	Chng_details chng;
	Pswd_change pswd;
	LogOut lgout;
	String autURL1, nodeURL1;
	
	
	
	@BeforeMethod
	  public void launchFirefox() throws MalformedURLException {
			autURL1 = "http://realestate.upskills.in/";
			nodeURL1 = "http://172.24.94.17:1996/wd/hub";
			DesiredCapabilities cap = DesiredCapabilities.firefox();
			  cap.setBrowserName("firefox");
			  cap.setPlatform(Platform.WINDOWS);
			  drs = new RemoteWebDriver(new URL(nodeURL1), cap);
			  drs.get(autURL1);
			  
	    }
	
	 @Test(priority = 1)
		public void test_login_pages()
		{
		
			lgs = new Login(drs);
			hps = new HomePage(drs);
		
			lgs.do_login("admin", "admin@123");
			drs.getTitle();
			drs.close();
			
			String actual_pn =hps.get_title();
			Assert.assertTrue(actual_pn.contains("Real Estate � WordPress"));
			
		}
	 
	@Test(priority = 2)
		public void change_details()
		{
			
			lgs = new Login(drs);
			hps = new HomePage(drs);
	
			lgs.do_login("admin", "admin@123");
		
			chng = new Chng_details(drs);
			chng.edit_name();
			chng.last_name("manzoor");
			chng.phone_no("9876543210");
			chng.submit_btn();
			drs.close();	
		}
	 
	 @Test(priority = 3)
		public void change_pwd()
		{
		 	
		 	lgs = new Login(drs);
			hps = new HomePage(drs);
		
			lgs.do_login("admin", "admin@123");
		 
		 	pswd = new Pswd_change(drs);
			pswd.edit_name();
			pswd.generate("admin@123");
			pswd.checkbox();
			pswd.submit_btn();
			//drs.getTitle();
			drs.close();
			
			String actual_pn =pswd.get_text();
			Assert.assertEquals(actual_pn, "Profile updated.");
				
			
		}
	 
	 @Test(priority = 4)
		public void logout_func()
		{
		 lgs = new Login(drs);
			hps = new HomePage(drs);
		
			lgs.do_login("admin", "admin@123");
			
		 
		 lgout = new LogOut(drs);
			//lgout.link();
			//lgout.edit_name();
			lgout.log_out();
			
			drs.close();
			String acn = lgout.get_result();
			Assert.assertEquals(acn,"My Profile" );
			
			
		} 
	 
}
	
	
	
	
	
	
	
	
	
	
	
