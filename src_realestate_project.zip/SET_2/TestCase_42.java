package SET_2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;

public class TestCase_42 {

	WebDriver dr;
	//*[@id="menu-posts"]/a/div[3]
	By post = By.xpath("//*[@id='menu-posts']/a/div[3]");
	By addnew = By.xpath("//*[@id='wpbody-content']/div[3]/a");
	By txt_title = By.xpath("//*[@id='title']");
	By txt_ar = By.xpath("//*[@id='content']");
	//*[@id="publish"]
	
	//*[@id="publish"]
	By pblsh = By.id("publish");
	//*[@id="menu-posts"]/ul/li[2]/a
	By apost = By.xpath("//*[@id='menu-posts']/ul/li[2]/a");
	//*[@id="post-3450"]/td[1]/div[3]/span[4]/a
	By vpost = By.xpath("//*[@id='post-3450']/td[1]/div[3]/span[4]/a");
	
	
	public TestCase_42(WebDriver dr)
	{
		this.dr = dr;
	}
		
	public void post_link()
	{
		dr.findElement(post).click();
	}
	public void add_new()
	{
		dr.findElement(addnew).click();
	}
	public void title_box(String tt)
	{
		dr.findElement(txt_title).sendKeys(tt);
	}
	public void text_area(String ta)
	{
		dr.findElement(txt_ar).sendKeys(ta);
	}
	public void publish()
	{	
		/*WebDriverWait wt =new WebDriverWait(dr, 50);
		wt.until(ExpectedConditions.elementToBeClickable(pblsh));
		*/
		dr.findElement(pblsh).click();
	}
	public void all_post()
	{
		dr.findElement(apost).click();
	}
	public void view_post()
	{
		dr.findElement(vpost).click();
	}
	public void test_post(String tb, String ta)
	{
		this.post_link();
		this.add_new();
		this.title_box(tb);
		this.text_area(ta);
		this.publish();
	}
	public String get_text()
	{
		return dr.findElement(By.xpath("//*[@id='message']/p/text()")).getText();
	}
	public String get_msg()
	{
	return dr.findElement(By.xpath("//*[@id='post-3450']/div/p")).getText();
	}
	
	
}
