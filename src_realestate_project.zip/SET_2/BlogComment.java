package SET_2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
//import org.testng.Assert;

public class BlogComment {

	WebDriver dr;
	By bloglink = By.xpath("//*[@id='menu-item-617']/a");
	By readmore = By.xpath("//*[@id='post-3524']/div/a");
	By cmnt = By.xpath("//*[@id='comment']");
	//*[@id="submit"]
	By sbmt = By.id("comment");
	
	public BlogComment(WebDriver dr)
	{
		this.dr = dr;
	}
		
	public void blog_link()
	{
		dr.findElement(bloglink).click();
	}
	public void read_more()
	{
		dr.findElement(readmore).click();
	}
	public void comment(String cmt)
	{
		dr.findElement(cmnt).sendKeys(cmt);
	}
	public void submit_btn()
	{
		dr.findElement(sbmt).click();
	}
	
	public void do_comment(String cm)
	{
		this.blog_link();
		this.read_more();
		this.comment(cm);
		this.submit_btn();
	}
	
	public String get_text()
	{
		return dr.findElement(By.xpath("//*[@id='commentform']/p[1]")).getText();
	}
	
	
	
	
}
