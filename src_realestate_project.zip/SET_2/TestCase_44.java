package SET_2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class TestCase_44 {

	WebDriver dr;
	//*[@id="menu-posts-property"]/ul
	By pro_link = By.xpath("//*[@id='menu-posts-property']/a/div[3]");
	By feat = By.xpath("//*[@id='menu-posts-property']/ul/li[4]/a");
	By name = By.xpath("//*[@id='tag-name']");
	By sname = By.xpath("//*[@id='tag-slug']");
	By descrp = By.xpath("//*[@id='tag-description']");	
	//*[@id="submit"]
	By adnew = By.xpath("//*[@id='submit']");														//Add New Feature btn click	
	
	By add = By.xpath("//*[@id='menu-posts-property']/ul/li[3]/a");									// Add Link in property
	By add_prop = By.xpath("//*[@id='title']");														//Property Title
	By prop_des = By.xpath("//*[@id='content']");													//Property description
	By fcheck = By.name("tax_input[property_feature][]");
	By publs = By.xpath("//*[@id='publish']");
	
	
	
	public TestCase_44(WebDriver dr)
	{
		this.dr = dr;
	}
		
	public void pro_link()
	{
		Actions action = new Actions(dr);
		WebElement element = dr.findElement(pro_link);
		action.moveToElement(element).perform();
		
	}
	public void feature()
	{
		dr.findElement(feat).click();
	}
	public void featurename(String fn)
	{
		dr.findElement(name).sendKeys(fn);
	}
	public void slugname(String sn)
	{
		dr.findElement(sname).sendKeys(sn);
	}
	public void descrp(String ds)
	{
		dr.findElement(descrp).sendKeys(ds);
	}
	public void add_btn()
	{
		dr.findElement(adnew).click();
	}
	public void add_link()
	{	
		Actions action = new Actions(dr);
		WebElement element = dr.findElement(pro_link);
		action.moveToElement(element).perform();

		
		dr.findElement(add).click();
	}
	public void Title_txtpro(String t)
	{
		dr.findElement(add_prop).sendKeys(t);
	}
	public void pro_descrtxt(String dc)
	{
		dr.findElement(prop_des).sendKeys(dc);
	}
		
	public void check_box()
	{
		java.util.List<WebElement> rb = dr.findElements(By.name("fcheck"));
		((WebElement) rb.get(0)).click();		
	}
	
	public void submit()
	{
		dr.findElement(publs).click();
	}


	
	public void prop_case(String ft, String s, String d, String tt, String pd)
	{
		this.pro_link();
		this.feature();
		this.featurename(ft);
		this.slugname(s);
		this.descrp(d);
		this.add_btn();
		this.add_link();
		this.Title_txtpro(tt);
		this.pro_descrtxt(pd);
		this.check_box();
		this.submit();
	}
}
