package SET_2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestCase_43 {

	
	WebDriver dr;
	By prop = By.xpath("//*[@id='menu-posts-property']/a/div[3]");
	By add = By.xpath("//*[@id='wpbody-content']/div[3]/a");
	By post_title = By.xpath("//*[@id='title']");
	By txt_area = By.xpath("//*[@id='content']");
	By pub = By.xpath("//*[@id='publish']");
	//*[@id="message"]/p/a
	By view = By.xpath("//*[@id=\"message\"]/p/a");
	
	public TestCase_43(WebDriver dr)
	{
		this.dr = dr;
	}
	public void property_clk()
		{
		dr.findElement(prop).click();
		}
	public void add_new1()
	{
	dr.findElement(add).click();
	}
	public void post(String s)
	{
	dr.findElement(post_title).sendKeys(s);
	}
	public void textar(String tx)
	{
	dr.findElement(txt_area).sendKeys(tx);
	}
	public void publish2()
	{
	dr.findElement(pub).click();
	}
	public void view_post()
	{
		WebDriverWait wt =new WebDriverWait(dr, 50);
		wt.until(ExpectedConditions.elementToBeClickable(view));
		
		dr.findElement(view).click();
		
	}
	public void prop_case(String p, String t)
	{
		this.property_clk();
		this.add_new1();
		this.post(p);
		this.textar(t);
		this.publish2();
		this.view_post();
	}
	/*public String get_msg()
	{	//*[@id="message"]/p
		
		return dr.findElement(By.xpath("//div[@id='message']/p")).getText();
	}                                     
	public String final_msg()
	{
		return dr.findElement(By.xpath("//*[@id='wrapper']/div[4]/div/div[1]/div/p")).getText();
	}
	*/
	//*[@id="wrapper"]/div[4]/div/div[1]/div/p
	
	
	
}
