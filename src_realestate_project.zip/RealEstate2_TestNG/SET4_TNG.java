package RealEstate2_TestNG;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import Realestate.HomePage;
import Realestate.Login;
import SET_2.BlogComment;
import SET_2.TestCase_42;
import SET_2.TestCase_43;
import SET_2.TestCase_44;

public class SET4_TNG {

	WebDriver dr;
	TestCase_42 pc;	
	BlogComment bc;
	Login lgs;
	HomePage hps;
	TestCase_43 pr;
	TestCase_44 pt;
	  @BeforeMethod
	  public void SetII_TC() 
	  
	  {
		  System.setProperty("webdriver.chrome.driver","chromedriver.exe");
		  dr = new ChromeDriver();
		  dr.get("http://realestate.upskills.in/");

	  }
	  
	  
	
	//@Test
	public void Blog_Comment()
	{
	
		bc = new BlogComment(dr);
		bc.blog_link();
		bc.read_more();
		bc.comment("GOOD");
		bc.submit_btn();
		//dr.close();
		
		String actual_pn =bc.get_text();
		Assert.assertEquals(actual_pn, "Comment should get added and displayed on the screen");
		
	}
	
	
	
	//@Test
	public void Post_Comment()
	{
		
		lgs = new Login(dr);
		hps = new HomePage(dr);
	
		lgs.do_login("admin", "admin@123");
	
		pc = new TestCase_42(dr);
		pc.post_link();
		pc.add_new();
		pc.title_box("New Launches");
		pc.text_area("New Launch in Home");
		pc.publish();
		pc.all_post();
		pc.view_post();
	
		String actual_pn =pc.get_text();
		Assert.assertEquals(actual_pn, "Post published.");
		
		String apn =pc.get_msg();
		Assert.assertEquals(apn, "New Launch in Home");
	}
	
	
	
	//@Test
	public void Property_Comment()
	{
		
		lgs = new Login(dr);
		hps = new HomePage(dr);
	
		lgs.do_login("admin", "admin@123");
	
		pr = new TestCase_43(dr);
		pr.property_clk();
		pr.add_new1();
		pr.post("new launch");
		pr.textar("new launch");
		pr.publish2();
		pr.view_post();

		
		/*String actual_pn =pr.get_msg();
		Assert.assertEquals(actual_pn, "Post published.");
		
		String apn =pr.final_msg();
		Assert.assertEquals(apn, "new launch");
*/
	}
	@Test
		public void feature_description()
		{
			
			lgs = new Login(dr);
			hps = new HomePage(dr);
		
			lgs.do_login("admin", "admin@123");
		
			pt = new TestCase_44(dr);
			pt.pro_link();
			pt.feature();
			pt.featurename("New Launches");
			pt.slugname("launch");
			pt.descrp("New Launches of villas, apartments, flats");
			pt.add_btn();
			pt.add_link();
			pt.Title_txtpro("prestige");
			pt.pro_descrtxt("home town");
			pt.check_box();
			pt.submit();


}
}